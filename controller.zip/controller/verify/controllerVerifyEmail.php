<?php
session_start();
if (!$_SESSION) {
    header('Location: ../../dist/login.php?error=true&message=No puedes acceder a esta pagina, inicia sesion con un usuario valido!&title=Acceso denegado');
    exit;
}
require_once '../../models/MySQL.php';
$mysql = new MySQL();
$mysql->conectar();
$email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
try {
    $sql = "SELECT * FROM usuarios WHERE correo_usuario = :email;";
    $stmt = $mysql->getConexion()->prepare($sql);
    $stmt->bindParam(":email", $email, PDO::PARAM_STR);
    $stmt->execute();
} catch (\Throwable $th) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Error al verificar email', 'error' => $th]);
};

$resultado = $stmt->fetch(PDO::FETCH_ASSOC);
$bool = true;
if ($resultado != false) {
    $bool = false;
}
header("Content-Type: application/json");
echo json_encode($bool);
