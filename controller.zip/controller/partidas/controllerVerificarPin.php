<?php
session_start();
header('Content-Type: application/json');


require_once '../../models/MySQL.php';
try {
    $mysql = new MySQL();
    $mysql->conectar();
    //consulta para verificar el pin
    $stmt = $mysql->getConexion()->prepare("SELECT * FROM partidas WHERE pin_partida = :pin_partida and estado_partida = 'Esperando' or estado_partida = 'Jugando'");
    $pinPartida = filter_input(INPUT_POST, 'pinIngresado', FILTER_SANITIZE_NUMBER_INT);
    $stmt->bindParam(':pin_partida', $pinPartida, PDO::PARAM_INT);
    $stmt->execute();
    $partida = $stmt->fetch(PDO::FETCH_ASSOC);
    $_SESSION['pinPartida'] = $pinPartida;
    if ($partida) {
        echo json_encode([
            'success' => true,
            'data' => $partida
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'PIN inválido o partida no disponible'
        ]);
    }
} catch (Exception $e) {
    echo json_encode([
        "error" => true,
        "message" => $e->getMessage(),
    ]);
} finally {
    // Cierre de conexion
    if (isset($mysql)) {
        $mysql->desconectar();
    }
}
